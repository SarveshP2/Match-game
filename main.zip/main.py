from tkinter import *
import random
from tkinter import messagebox

root = Tk()
root.title("Tkinter project by Sarvesh")
root.geometry("600x550")


Answer = [1,1,2,2,3,3,4,4,5,5,6,6]
Answer[0]

random.shuffle(Answer)

my_frame = Frame(root)
my_frame.pack(pady=10)

count = 0
ans = []
ansd = {}

Labelww = Label(root, text="""How to play:
Click one box and remember the box position and number and click another box and guess it correctly""", bg='yellow')
Labelww.pack(pady=60)


def button_click(b, number):
    global count, ans, ansd

    if b["text"] == ' ' and count < 2:
        b["text"] = Answer[number]
        ans.append(number)
        ansd[b] = Answer[number]

        count += 1

    if len(ans) == 2:
    	if Answer[ans[0]] == Answer[ans[1]]:
    		Labeel.config(text="Match!!")
    		for key in ansd:
    			key["state"] = "disabled"
    		count = 0
    		ans = []
    		ansd = {}
    	else:
    		Labeel.config(text="Oh!")
    		count = 0
    		ans = []

    		messagebox.showinfo("Incorret!", "Icorrect")
    	
    		for key in ansd:
    			key["text"] = " "

    		ansd = {}
button0 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button0, 0))
button1 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button1, 1))
button2 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button2, 2))
button3 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button3, 3))
button4 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button4, 4))
button5 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button5, 5))
button6 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button6, 6))
button7 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button7, 7))
button8 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button8, 8))
button9 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button9, 9))
button10 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button10, 10))
button11 = Button(my_frame, text=' ',bg='grey', height=3, width=6, font=("Helvetica", 20),command=lambda: button_click(button11, 11))

button0.grid(row=0, column=0)
button1.grid(row=0, column=1)
button2.grid(row=0, column=2)
button3.grid(row=0, column=3)

button4.grid(row=1, column=0)
button5.grid(row=1, column=1)
button6.grid(row=1, column=2)
button7.grid(row=1, column=3)

button8.grid(row=2, column=0)
button9.grid(row=2, column=1)
button10.grid(row=2, column=2)
button11.grid(row=2, column=3)

Labeel = Label(root, text=" ")
Labeel.pack(pady=20)


root.mainloop()
